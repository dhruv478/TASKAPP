package com.example.taskappwithsql

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.taskappwithsql.databinding.ActivityLoginBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class LoginActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityLoginBinding
    private lateinit var Email: EditText
    private lateinit var Password: EditText
    private lateinit var Login: Button
    private lateinit var Register: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        Email = findViewById(R.id.etEmail)
        Password = findViewById(R.id.etPassword)
        Login = findViewById(R.id.btnLogin)
        Register = findViewById(R.id.tvRegister)
        Register.setOnClickListener{
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
        Login.setOnClickListener{
            val Email = Email.text.toString()
            val Password = Password.text.toString()
                if (Email.isNotEmpty() && Password.isNotEmpty()) {
                    auth.createUserWithEmailAndPassword(Email,Password).addOnCompleteListener(this) { task ->

                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)}
                }else{
                    Toast.makeText(this, "Please Enter Email and Password", Toast.LENGTH_SHORT)
                        .show()
                }


        }
    }
}