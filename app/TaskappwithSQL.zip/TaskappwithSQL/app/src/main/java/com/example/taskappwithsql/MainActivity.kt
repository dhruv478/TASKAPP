 package com.example.taskappwithsql

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.taskappwithsql.databinding.ActivityMainBinding

 class MainActivity : AppCompatActivity() {
    private lateinit var dbHelper: TaskDBHelper
     private lateinit var taskAdapter: TaskAdapter
     private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        dbHelper = TaskDBHelper(this)
        taskAdapter = TaskAdapter(
            deleteTask = { id -> deleteTask(id) },
            editTask = { task -> showEditTaskDialog(context = this,task = task) })
        binding.recyclerViewTasks.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewTasks.adapter = taskAdapter
        getTasks()
        binding.addNote.setOnClickListener{
            showAddTaskInputDialog(this)
        }
    }
     fun showAddTaskInputDialog(context: Context){
         val view = LayoutInflater.from(context).inflate(R.layout.dialog_task_input, null)
         val dialogBuilder = AlertDialog.Builder(context)
             .setView(view)
             .setTitle("Add Task")
         val taskNameEditText = view.findViewById<EditText>(R.id.et_taskName)
         val taskDescriptionEditText = view.findViewById<EditText>(R.id.et_taskDescription)
         val submitButton = view.findViewById<Button>(R.id.btnsubmit)
         val dialog = dialogBuilder.create()
         submitButton.setOnClickListener {
             val taskName = taskNameEditText.text.toString()
             val taskDescription = taskDescriptionEditText.text.toString()
             addTask(taskName, taskDescription)
             dialog.dismiss()
         }
         dialog.show()
     }
     fun showEditTaskDialog(context: Context, task: Task){
         val view = LayoutInflater.from(context).inflate(R.layout.dialog_task_input, null)
         val dialogBuilder = AlertDialog.Builder(context)
             .setView(view)
             .setTitle("Edit Task")
         val taskNameEditText = view.findViewById<EditText>(R.id.et_taskName)
         val taskDescriptionEditText = view.findViewById<EditText>(R.id.et_taskDescription)
         val submitButton = view.findViewById<Button>(R.id.btnsubmit)
         val dialog = dialogBuilder.create()
         submitButton.setOnClickListener {
             val taskName = taskNameEditText.text.toString()
             val taskDescription = taskDescriptionEditText.text.toString()
             addTask(taskName, taskDescription)
             dialog.dismiss()
         }
         dialog.show()
     }
     private fun addTask(taskName: String, taskDescription: String){
         val task = Task(title = taskName, description = taskDescription)
         dbHelper.addTask(task)
         getTasks()
     }
     fun getTasks(){
         val alltask = dbHelper.getAllTasks()
         taskAdapter.setTasks(alltask)
     }
     private fun editTask(id: Int,taskName:String,taskDescription:String){
         val updateTask = Task(id = id,title = taskName,description = taskDescription)
         dbHelper.updateTask(updateTask)
         getTasks()
     }
     private fun deleteTask(id:Int){
         dbHelper.deleteTask(id.toString())
         getTasks()
     }
}